<?php
$kon=mysqli_connect("localhost","root","root","sig") or die ("Gagal Koneksi");
mysqli_select_db($kon,'sig')or die("Database gak Konek");
?>